package cornerTeam;

import static org.junit.Assert.*;

import org.junit.Test;

public class CornerTeamTest {

	@Test
	public void TestSetupSearchPanel() {
		View window = new View();
		window.setupSearchPanel(window.searchPanel);
		assertNotNull(window);
	}
	
	@Test public void TestSetupAdminPanel()
	{
		View window = new View();
		window.setupAdminPanel(window.adminPanel);
		assertNotNull(window);
	}
	
	@Test public void TestRebuildIndex()
	{
		fail("Not yet implemented");
	}
	
	@Test public void TestRemoveFromIndexDatabase()
	{
		fail("Not yet implemented");
	}
	
	@Test public void TestAddToIndexDatabase()
	{
		fail("Not yet implemented");
	}
	
	@Test public void TestReturnIndex()
	{
		fail("Not yet implemented");
	}
	
	@Test public void TestFileModified()
	{
		fail("Not yet implemented");
	}
	
	@Test public void TestFileExists()
	{
		fail("Not yet implemented");
	}
	
	@Test public void TestSetLastModified()
	{
		fail("Not yet implemented");
	}

}
