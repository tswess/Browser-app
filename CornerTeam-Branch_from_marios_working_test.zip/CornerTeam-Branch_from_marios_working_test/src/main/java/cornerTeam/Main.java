//This class is the Main class of CornerTeams search engine program
//and contains the main method.

package cornerTeam;

import java.awt.HeadlessException;
import java.text.ParseException;
import java.util.*;
import javax.persistence.*;
import java.io.*;
import javax.swing.JFrame;
import cornerTeam.Index;

public class Main {
	
	public static void main(String[] args) throws HeadlessException, ParseException, IOException
	{
		//rebuild index will make sure all files are present and has updated file names paths and hasn't
		//been modified. 
		Index.rebuildIndex();
		
		
		
		
		//REBUILD INVERTED INDEX
		//THIS WILL CAUSE OUR INVERTED INDEX TO BE UP TO DATE EVERY TIME THE PROGRAM STARTS
		//BECAUSE THE REBUILDINDEX METHOD ABOVE ALREADY MAKES SURE THAT THE FILES EXIST
		//AND HAVE NOT BEEN MODIFIED. 
		//THE METHOD HERE SHOULD ONLY BUILD THE INVERTED INDEX AND PRINT THE INVERTED INDEX
		//TO A LOCAL TEXT FILE FOR VIEWING, AND AGAIN BASED ON THE METHOD ABOVE, IT WILL ALWAYS BE UP TO DATE
		//AT THE START OF THE PROGRAM.
		//ANOTHER OPTION WOULD BE TO PUT THE INVERTED INDEX BUILD INSIDE OF THE REBUILDINDEX() METHOD, IT MAY LOOK
		//AND OPERATE BETTER 
		
		// Construct View class object
		View window = new View();
    	
		// Populate the Search Engine panel, setup its visibility and "pack" the window to fit all items
		window.setupSearchPanel(window.searchPanel);
		window.searchFrame.getContentPane().add(window.searchPanel);
		window.searchFrame.setVisible(true);
		window.searchFrame.pack();
		window.searchFrame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
    	
		// Populate the Admin panel, and add functionality for EXIT
		window.setupAdminPanel(window.adminPanel);
		window.adminFrame.getContentPane().add(window.adminPanel);
		window.adminFrame.pack();
		
		
	}	
}

