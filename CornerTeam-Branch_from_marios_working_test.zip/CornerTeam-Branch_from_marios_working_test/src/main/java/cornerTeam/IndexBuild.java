package cornerTeam;
import java.io.*;
import java.util.*;

public class IndexBuild 
{
    Map<Integer, String> mapCoord;
    HashMap<String, HashSet<Integer>> indexMap;
    HashMap<String, HashSet<Integer>> wordMap;
    public int numberOfFiles;
    final static String outputFilePath = "C:\\temp\\InvertedIndex.txt";
    String fileLines[];
    
    IndexBuild()
    {
    	// mapCoord is the map for 
    	mapCoord = new HashMap<Integer,String>();
        indexMap = new HashMap<String, HashSet<Integer>>();
        wordMap = new HashMap<String, HashSet<Integer>>();
    }
    
    public void buildIndex(String[] files) throws IOException	
    {
    	int i = 0;
    	int fileCount = 0;
    	int wordCounter = 0;
    	
    	//new File object
        File invertedIndex = new File(outputFilePath);
        //clear the file to no text
        invertedIndex.delete();
        
    	BufferedWriter bf = new BufferedWriter( new FileWriter(invertedIndex));
    	
        for(String fileName:files)
        {  
            try(BufferedReader file = new BufferedReader(new FileReader(fileName)))
            {
            	// "put()" method will insert the fileName and current iteration into the mapCoord HashMap
            	mapCoord.put(i/**fileCount**/, fileName);
            	System.out.println(mapCoord.get(fileCount) + "u r here");
            	fileCount++;

                bf.write("File: " + fileName );
            	bf.write("= Hash: " + fileCount);
            	bf.newLine();
            	bf.flush();
            	
            	
            	// Define the variable holding the read line (from the file given)
                String line;
                
                // This while loop will go through each read line as long as it is not empty
                while((line = file.readLine()) != null)
                {               	
                	// Create variable "words" which will be an array of all the words in the read line
                	// The words are split whenever there's a non word
                    String[] words = line.split("\\W+");
                    
                    // This "for" loop will go through each of those words
                    for(String word:words)
                    {                 
                    	// Replace the read word with its lowercase equivalent
                        word = word.toLowerCase();
                        wordCounter++;
                        
                        if (!indexMap.containsKey(word))
                        {
                        	indexMap.put(word, new HashSet<Integer>());
                        	wordMap.put(word, new HashSet<Integer>());
                        }
                        
                        // indexMap array will collect the resulting "word" and add the current iteration
                        // number to the mapping
                        indexMap.get(word).add(i);
                        wordMap.get(word).add(wordCounter);
                       
                    }
                   
                }
            } catch (IOException e)
            
            {
                System.out.println("File name: " + fileName + " not found. Skip it");
            }
            
            i++;
            
            bf.write("Words for file number: " + fileCount);
            bf.newLine();
            for(Map.Entry<String, HashSet<Integer>> indexes : wordMap.entrySet())
            {
                //put key and value separated by a colon
                bf.write( "Word: " + indexes.getKey() + " Word Number: " + indexes.getValue() );
                
                //new line
                bf.newLine();
            } 
            
            bf.newLine();
            i++;
        }
        
       
        bf.close();
    }
    
    public void find(String phrase)
    {
        String[] words = phrase.split("\\W+");
        HashSet<Integer> res = new HashSet<Integer>(indexMap.get(words[0].toLowerCase()));
        
        for(String word: words)
        {
            res.retainAll(indexMap.get(word));
        }

        if(res.size()==0) 
        {
            System.out.println("Not found");
            return;
        }
        
        System.out.println("Found in: ");
        
        
        IndexBuild invertedIndex = new IndexBuild();
        
        System.out.println(this.mapCoord.get(0));
        
        
        int i = 0;
        for(int num : res)
        {
        	
        	System.out.println(num + " num ");
        	
            System.out.println("YOUR SEARCH TERM ['"+phrase+"'] WAS FOUND HERE:\t" + mapCoord.get(num) + "  using i " + this.mapCoord.get(i));
            
        	i++;
        }
    }
}