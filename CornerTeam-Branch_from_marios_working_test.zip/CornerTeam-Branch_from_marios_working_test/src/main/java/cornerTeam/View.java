package cornerTeam;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.*;
import javax.swing.DefaultListModel;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

import cornerTeam.Index;

// This class is responsible for containing all field names, and implementing
// the ActionListener event handler for the Search Engine panel functionality
public class View extends JFrame implements ActionListener
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//Construct Frame and Panel objects
	JFrame searchFrame = new JFrame();
	JFrame adminFrame = new JFrame();
	JPanel searchPanel = new JPanel();
	JPanel adminPanel = new JPanel();

	//Declare components of the Search Engine view
	JLabel lblsearch;
	JTextField txtSearchBar;
	JRadioButton rbtnAnd;
	JRadioButton rbtnOr;
	JRadioButton rbtnExactPhrase;
	JButton btnSearch;
	JList lstSearchView;
	JButton btnExit;
	JButton btnAbout;
	JButton btnAdmin;

	//Declare components of the Admin Maintenance view
	String[] dataItems = {};
	List<String> fileData = new ArrayList<>();
	JButton btnResetWindows;
	JButton btnAddFile;
	JButton btnRebuild;
	JButton btnRemoveFiles;
	JButton btnRemoveAll;
	JLabel lblIndexMaintenance;
	String[] columnNames = {"File Name","Status"};
	Object[][] files = {};
	JList<String> lstFileView;
	DefaultListModel<String> listModel;
	JScrollPane scrollPane;
	JLabel numberOfIndexedFiles;
	
	int numberOfFiles;

	// This method will contain all relevant components to the Admin Maintenance panel
	public void setupAdminPanel(JPanel panel) 
	{
		//assign components for AdminPanel
		btnResetWindows = new JButton ("Reset Windows");
		btnResetWindows.addActionListener(this);
		btnAddFile = new JButton ("Add File");
		btnAddFile.addActionListener(this);
		btnRebuild = new JButton ("Rebuild Out-of-Date");
		btnRebuild.addActionListener(this);
		btnRemoveFiles = new JButton ("Remove Selected Files");
		btnRemoveFiles.addActionListener(this);
		btnRemoveAll = new JButton ("Del. All Files");
		btnRemoveAll.addActionListener(this);
		lblIndexMaintenance = new JLabel ("Index Maintenance");
		lstFileView = new JList (fileData.toArray());
		listModel = new DefaultListModel();
		scrollPane = new JScrollPane(); 
		numberOfIndexedFiles = new JLabel();
		
		// Setup for the list located in the Admin Panel
		lstFileView.setEnabled (true);
		scrollPane.setViewportView(lstFileView);
		lstFileView.setLayoutOrientation(JList.VERTICAL);
		
		//adjust size and set layout of panel 
		panel.setPreferredSize (new Dimension (667, 366));
		panel.setLayout (null);

		//add components to panel
		panel.add (btnResetWindows);
		panel.add (btnAddFile);
		panel.add (btnRebuild);
		panel.add (btnRemoveFiles);
		panel.add (btnRemoveAll);
		panel.add (lblIndexMaintenance);
		panel.add (scrollPane);
		panel.add(numberOfIndexedFiles);

		//set component bounds (only needed by Absolute Positioning)
		lblIndexMaintenance.setBounds (275, 0, 140, 35);
		btnAddFile.setBounds (8, 140, 160, 25);
		btnRebuild.setBounds (8, 180, 160, 25);
		btnRemoveFiles.setBounds (8, 220, 160, 25);
		btnResetWindows.setBounds (8, 260, 160, 25);
		btnRemoveAll.setBounds (8, 332, 125, 25);
		lstFileView.setBounds (175, 30, 490, 330);
		scrollPane.setBounds(175, 30, 490, 330);
		numberOfIndexedFiles.setBounds(10,10,160,25);
	}

	// This method will contain all relevant components to the Search Engine panel
	public void setupSearchPanel(JPanel panel) 
	{		
		//construct components
		lblsearch = new JLabel ("Search: ");
		txtSearchBar = new JTextField (1);
		rbtnAnd = new JRadioButton ("All Key Words");
		rbtnAnd.addActionListener(this);
		rbtnOr = new JRadioButton ("Any Key Words");
		rbtnOr.addActionListener(this);
		rbtnExactPhrase = new JRadioButton ("Exact Phrase");
		rbtnExactPhrase.addActionListener(this);
		btnSearch = new JButton ("Search");
		btnSearch.addActionListener(this);
		lstSearchView = new JList (this.dataItems);
		btnExit = new JButton ("Exit");
		btnExit.addActionListener(this);
		btnAbout = new JButton ("About");
		btnAbout.addActionListener(this);
		btnAdmin = new JButton ("Admin");
		btnAdmin.addActionListener(this);
		
		// Group of radio buttons. necessary for the user to only select a
		// singular radio button
		ButtonGroup radioButtons = new ButtonGroup();
		radioButtons.add(rbtnAnd);
		radioButtons.add(rbtnExactPhrase);
		radioButtons.add(rbtnOr);

		//set components properties
		lstSearchView.setEnabled (true);

		//adjust size and set layout
		panel.setPreferredSize (new Dimension (667, 366));
		panel.setLayout (null);

		//add components
		panel.add (lblsearch);
		panel.add (txtSearchBar);
		panel.add (rbtnAnd);
		panel.add (rbtnOr);
		panel.add (rbtnExactPhrase);
		panel.add (btnSearch);
		panel.add (lstSearchView);
		panel.add (btnExit);
		panel.add (btnAbout);
		panel.add (btnAdmin);

		//set component bounds (only needed by Absolute Positioning)
		lblsearch.setBounds (25, 5, 100, 25);
		txtSearchBar.setBounds (100, 10, 430, 20);
		rbtnAnd.setBounds (110, 40, 110, 25);
		rbtnOr.setBounds (270, 40, 120, 25);
		rbtnExactPhrase.setBounds (425, 40, 115, 25);
		btnSearch.setBounds (560, 5, 100, 25);
		lstSearchView.setBounds (20, 65, 525, 295);
		btnExit.setBounds (560, 65, 100, 25);
		btnAbout.setBounds (555, 330, 100, 25);
		btnAdmin.setBounds (555, 275, 100, 25);
		this.add(panel);
	}

	@Override
	// This method will detail the related actions for each button press using an "if"
	// statement
	public void actionPerformed(ActionEvent e)
	{
		// This button will open the Admin panel. It will also populate the Admin List
		// with all the file path names included in the database.
		if (e.getSource() == btnAdmin)
		{
			//code to execute when button is pressed
			this.adminFrame.setVisible(true);

			// Create EMF and EM
			EntityManagerFactory emf = Persistence.createEntityManagerFactory( "MyDB_CornerTeam03" );
			EntityManager em = emf.createEntityManager();

			// Create query that will return all records in the Index table
			Query getAllIndex = em.createQuery("SELECT x FROM Index x");
			@SuppressWarnings("unchecked")
			List<Index> listIndex = getAllIndex.getResultList();

			// For each record collected by the query, add that record's file path value
			// to the Admin List
			for (Index index : listIndex )
			{
				//temporary File object to make sure the file exists
				File fileExists = new File(index.getFilePath());
				
				// This "if" statement will prevent duplicate files from adding if the user
				// clicks the "Admin" button more than once
				// it also makes sure that the file still exists on the system.
				if (listModel.contains(index.getFilePath()) && fileExists.exists())
				{
					continue;
				}
				else if (index.fileExists())
				{
					listModel.addElement(index.getFilePath());
				}
				else
				{
					listModel.removeElement(index.getFilePath());
				}
			}

			// Sets the list view and updated the count of files being indexed
			lstFileView.setModel(listModel);
			numberOfFiles = lstFileView.getModel().getSize();
			numberOfIndexedFiles.setText("Number of Files Indexed: " + numberOfFiles);
			
			// Close EM and EMF
			em.close();
			emf.close();
		}
		
		// This button will prompt the user for confirmation of their termination of the program
		else if (e.getSource() == btnExit)
		{
			int exit = JOptionPane.showConfirmDialog(null, "This will exit the program and all information will be lost, Are you sure you want to Exit? ");
			if (exit == 0)
			{
				System.exit(0);
			}
		}
		
		// This button will execute the search parameters entered by the user depending on
		// the radio button that was selected by the user
		else if (e.getSource() == btnSearch)
		{
			if (rbtnAnd.isSelected())
			{
				EntityManagerFactory emf = Persistence.createEntityManagerFactory( "MyDB_CornerTeam03" );
				EntityManager em = emf.createEntityManager();
	    	
				// Create query that will return all records in the Index table
				Query getAllIndex = em.createQuery("SELECT x FROM Index x");
				@SuppressWarnings("unchecked")
				List<Index> listIndex = getAllIndex.getResultList();
	    	
				//handle and search
				String strSearchedText = this.txtSearchBar.getText();
			
				IndexBuild indexBuild = new IndexBuild();
			
				int numOfFiles = 0;
				for(Index index : listIndex)
				{
					numOfFiles++;
					//indexBuild.buildIndex(new String[]{"C:\\Users\\OscarAlien\\Desktop\\testfile1.txt","C:\\\\Users\\\\OscarAlien\\\\Desktop\\\\testfile2.txt"});
					//indexBuild.buildIndex(listIndex);
				}
			
				String[] fileFeed = new String[numOfFiles];
				System.out.println("numOfFiles: "+numOfFiles);
				
				int n = 0;
				for(Index index : listIndex)
				{
				//System.out.println("index.getFilePath(): "+index.getFilePath());
				fileFeed[n] = index.getFilePath();									//.replace("\\","\\\\");
				System.out.println("in the .replace loop: "+fileFeed[n]+ "       value of n:" + n);
				n++;
				
				}	
				
				try 
				{
					indexBuild.buildIndex(fileFeed);
				} 
				catch (IOException e1) 
				{
				
					e1.printStackTrace();
				}
				
	        	indexBuild.find(strSearchedText);
		        em.close();
			}
			
			else if (rbtnOr.isSelected())
			{
				//handle or search
			}
			
			else if (rbtnExactPhrase.isSelected())
			{
				EntityManagerFactory emf = Persistence.createEntityManagerFactory( "MyDB_CornerTeam03" );
		    	EntityManager em = emf.createEntityManager();
		    	
		    	// Create query that will return all records in the Index table
		    	Query getAllIndex = em.createQuery("SELECT x FROM Index x");
		    	@SuppressWarnings("unchecked")
		    	List<Index> listIndex = getAllIndex.getResultList();
		    	
				//handle and search
				String strSearchedText = this.txtSearchBar.getText();
				
				IndexBuild indexBuild = new IndexBuild();
				
				int numOfFiles = 0;
				for(Index index : listIndex)
				{
					numOfFiles++;
				}
				
				String[] fileFeed = new String[numOfFiles];
				
				int n = 0;
				for(Index index : listIndex)
				{
					
					fileFeed[n] = index.getFilePath().replace("\\","\\\\");
					n++;
				}
				try 
				{
					indexBuild.buildIndex(fileFeed);
				} catch (IOException e1) {
					
					e1.printStackTrace();
				}
				
		        indexBuild.find(strSearchedText);
		        
		        em.close();
			}
			
			//display search results in list
		}
		
		// This button will display a dialog box with information regarding the program and
		// its developers
		else if (e.getSource() == btnAbout)
		{
			JOptionPane.showMessageDialog(null, "Search Engine By Mario Gomez, Errol Keith, and Tyler Swessel\n" + "(address for the indexed txt file goes here)");
			//handler for about button

			//code for radio buttons goes here, need to create a switch case statement
			//to pick the button and use the selected case for search parameters.
		}

		else if (e.getSource() == btnResetWindows)
		{
			//handler for reset window button
		}

		// This button will prompt the user with a dialog box that displays the user's
		// current local directories. User will select a single file to add to the list
		// and the database
		else if (e.getSource() == btnAddFile)
		{
			// Opens the local directory chooser for the user
			JFileChooser openFile = new JFileChooser();
			
			// This filter will only allow the user to select text files for entry in
			// the database and Admin list
			FileNameExtensionFilter filter = new FileNameExtensionFilter("TEXT FILES", "txt", "text");
			openFile.setFileFilter(filter);
			openFile.setFileSelectionMode(JFileChooser.FILES_ONLY);
			int returnValue = openFile.showOpenDialog(null);
			
			// Create new object of type Index for use in updating the database
			Index indexInfo = new Index();

			// Checks selected file and verifies if the file exists or not in the database and
			// the Admin list
			if(returnValue == JFileChooser.APPROVE_OPTION)
			{
				// Creates variables to hold the file's entire path on the usere's
				// local directory, and to hold the file's name
				String filePath = openFile.getSelectedFile().getAbsolutePath();
				String inputFileName = openFile.getSelectedFile().getName();
				
				// Decision structure to determine if the listed file already exists
				if (listModel.contains(filePath))
				{
					// Displayed message if the file selected by the user is a duplicate
					JOptionPane.showMessageDialog(null, "This file already exists in the index");
				}
				else 
				{
					// If the file does not exist, this else statement will execute the process to
					// add all necessary information to the Admin List and the database
					indexInfo.setFileName(inputFileName);
					indexInfo.setFilePath(filePath);
					indexInfo.setlastModified();

					//fileData.add(indexInfo.getFileName());
					listModel.addElement(indexInfo.getFilePath());
					lstFileView.setModel(listModel);
					
					//add to database
					indexInfo.addToIndexDatabase();
					try {
						Index.rebuildIndex();
						}
						catch (Exception ex)
						{
							System.out.println("failed in add single file");
						}
				}
			}
			
			// Update the index count in Admin Panel
			numberOfFiles = lstFileView.getModel().getSize();
			numberOfIndexedFiles.setText("Number of Files Indexed: " + numberOfFiles);
		}

		else if (e.getSource() == btnRebuild)
		{
			//handler for rebuild button
			
			//change label for index count
			numberOfFiles = lstFileView.getModel().getSize();
			numberOfIndexedFiles.setText("Number of Files Indexed: " + numberOfFiles);
			
			try {
				Index.rebuildIndex();
				}
				catch (Exception ex)
				{
					System.out.println("failed in rebuild selection");
				}
		}

		// This button will prompt the user to confirm the deletion of all items listed in the Admin List,
		// and all the records in the database
		else if (e.getSource() == btnRemoveAll)
		{
			// Populates the pop-up dialog box asking user to confirm removal of all items in list and db
			int reply = JOptionPane.showConfirmDialog(null, "WARNING: You are about to delete all records in the database. Would you like to continue?", "Delete all records?", JOptionPane.YES_NO_OPTION);

			// This if statement will execute the deletion of all items in the Admin List and all
			// the records in the "Index" table of the database
			if (reply == JOptionPane.YES_OPTION)
			{				
				// Create the EM
				EntityManager em = Index.indexFactory.createEntityManager();

				// Open the transaction, create the query to delete all items in the "Index" table
				em.getTransaction().begin();
				Query getAllIndex = em.createQuery("DELETE FROM Index");
				getAllIndex.executeUpdate();
				em.getTransaction().commit();

				// Close the EM
				em.close();
				
				try {
					Index.rebuildIndex();
					}
					catch (Exception ex)
					{
						System.out.println("failed in remove all selection");
					}

				// Remove all elements of listModel which removes all items in the Admin List
				listModel.removeAllElements();
				
				//change label for index count
				numberOfFiles = lstFileView.getModel().getSize();
				numberOfIndexedFiles.setText("Number of Files Indexed: " + numberOfFiles);
				
			}
		}

		// This button will remove a single item from the Admin list and the same item will be removed
		// from the database. The item removed will be whichever is highlighted by the user
		else if (e.getSource() == btnRemoveFiles)
		{
			// Return the position of the highlighted item, and save it's value as a String in order
			// to search that record in the db using the below query
			int selectedItem = lstFileView.getSelectedIndex();
			String selectedItemName = (String) lstFileView.getSelectedValue();

			// An item will only be removed if the position selected is within bounds. I mainly
			// added this to prevent errors
			if (selectedItem != -1) 
			{
				// Remove the user selected item from the list only
				listModel.remove(selectedItem);
				
				EntityManager em = Index.indexFactory.createEntityManager();
				// Create the query that will find the single record which belongs to the highlighted item
				Query getONEIndex = em.createQuery("SELECT x FROM Index x WHERE x.filePath = '"+ selectedItemName +"'");
				Index singleQueryResult = (Index) getONEIndex.getSingleResult();
				em.close();
				
				// remove field
				singleQueryResult.removeFromIndexDatabase();
				try {
					Index.rebuildIndex();
					}
					catch (Exception ex)
					{
						System.out.println("failed in remove single selection");
					}
			}
			
			//change label for index count
			numberOfFiles = lstFileView.getModel().getSize();
			numberOfIndexedFiles.setText("Number of Files Indexed: " + numberOfFiles);
			
		}
		
	}
}