//This class sets up the schema for the db. 
//It contains a table name files with the columns
//ID (automatically generated), File Name, File Path,
//Deleted(if true the file has been deleted), and last modified
//(last modified is set to the creation date as a default)

package cornerTeam;

import java.awt.HeadlessException;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Calendar;


import javax.persistence.*;
import javax.swing.JOptionPane;

import cornerTeam.Index;

@Entity 
@Table (name = "INDEX")
public class Index 
{
	// This Index class is used to set up actions and properties of the database difined in the persistence.xml
	// file. Most importantly, it will contain the methods for applying and retrieving the individual values
	// of each record, and will also contain the description of all the DB fields
	
    @Id @GeneratedValue
    private int id;						// The primary ID of a given record. The ID is unique
    public String fileName;				// The name of the file only. It includes the type of file
    public String filePath;				// The full file name, aka - the File Path
    public boolean deleted = false;		// Holds True or False value depending on the status of the file existing or not
    @Temporal(TemporalType. DATE)
    public Date lastModified;			// Holds the date the file was last modified. This is originally defined by the
    									// user's Operating System automatically
    
    // Define the current name of the database as described in the persistence.xml file
    public static final String databaseName = "MyDB_CornerTeam03";
    public static EntityManagerFactory indexFactory = Persistence.createEntityManagerFactory( databaseName );

    // Constructor method for Index type variables
    public Index()
    {
        Date today = new Date();
        this.lastModified = today;
    }
    
    // Method to return the value of the current record's ID
    public int getId()
    {
        return this.id;
    }

    // Method to return the value of the current record's File Name
    public String getFileName()
    {
        return this.fileName;
    }

    // Method to return the value of the current record's File Path
    public String getFilePath()
    {
        return this.filePath;
    }

    // Method to return the value of the current file present status
    public boolean getDeleted()
    {
        return this.deleted;
    }

    // Method to return the value of the current record's last modified date
    public Date getlastModified()
    {
        return this.lastModified;
    }

    // Method to apply the given value as the current record's File Name
    public void setFileName(String name)
    {
        this.fileName = name;
    }

    // Method to apply the given value as the current record's File Path
    public void setFilePath(String path)
    {
        this.filePath = path;
    }

    // Method to apply the given value as the current file's present status
    public void setDeletedTrue() 
    {
        this.deleted = true;
    }

    // Method to apply the given value as the current record's last modified date
    public void setlastModified()
    {
        Date today = new Date();
        this.lastModified  = today;
    }
    
    // This method will determine if a given file exists in the system or not
    public boolean fileExists()
    {
    	boolean exists = false;								// The return variable
    	File fileExists = new File(this.getFilePath());		// Collect the file info for given file
    	
    	// This decision block will provide checks to return a value depending on if the file exists
    	// or not. If the file does NOT exist any longer, an entity manager will be created to
    	// remove the record from the DB for the file that was not found
    	if (fileExists.exists() == true)
    	{
    		// If the file given still exists in the system, a simple True value will be returned
    		exists = true;
    		return exists;
    	}
    	else
    	{
    		// Create the entity manager and a new object of type Index
    		EntityManager em = Index.indexFactory.createEntityManager();
        	Index indexInfo = new Index();
        	
        	// Create the query that will find the record with the file being searched. A single
        	// result will be produced
        	Query getONEIndex = em.createQuery("SELECT x FROM Index x WHERE x.filePath = '"+ fileExists +"'");
    		Index singleQueryResult = (Index) getONEIndex.getSingleResult();
    		
    		// use EM method "find()" to provide Index object "indexInfo" the record's ID
    		indexInfo = em.find(Index.class, singleQueryResult.getId());

    		// Open the transaction, remove the record, complete transaction
    		em.getTransaction().begin();
    		em.remove(indexInfo);
    		em.getTransaction().commit();
    		
    		// This dialog box will present the user with the outcome of the file's lack of existence
    		JOptionPane.showMessageDialog(null, (indexInfo.getFileName() + "The file no longer exists on the system and has been deleted from the DB"));
    		return exists;
    	}
    }
    
    // This method will be used to determine if a given file has been modified or not
    public boolean fileModified() throws ParseException
    {
    	boolean modified = false;
    	try 
    	{    		
    		//get last modified form the system file 
    		//and store it in a simple date format
        	File systemFile = new File(this.getFilePath());
        	SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        	String lastModifiedDate = dateFormat.format(systemFile.lastModified());
        	Date systemFileDate = dateFormat.parse(lastModifiedDate);
        	
        	//get last modified from the database file
        	//and store it in a simple date format
        	String finalDate = dateFormat.format(this.getlastModified());
        	Date databaseFileDate = dateFormat.parse(finalDate);
        			
        	//if date from database is older than system file date
        	if (databaseFileDate.compareTo(systemFileDate) < 0)
        	{
        		modified = true;
        	}
    	}
    	
    	catch (ParseException ex)
    	{
    		ex.printStackTrace();
    	}
    	
    	// This return statement will return True or False, indication if the given file has had
    	// a change in it's modified date or not
		return modified;	
    }
    
    // Placeholder method
    public void returnIndex()
    {
    	//this method will use the database to get the file paths for the files on the system
    	//check that the file exists
    	//add the files inverted index to the InvertedIndex text file in the users home directory.
    }
    
    // This method will be used as a replacement to the several "em.persist()" methods throughout
    // this application. It will assist in simplifying the code, and organizing other methods more
    // thoroughly
    public void addToIndexDatabase()
    {
    	// Create the Entity Manager and Entity Transaction
    	EntityManager em = Index.indexFactory.createEntityManager();
    	EntityTransaction et = em.getTransaction();
    	
    	// Steps to persist and commit changes made
		et.begin();
		em.persist(this);
		et.commit();
		em.close();
    }
    
    // This method will be used as a replacement to the "em.remove()" methods used in the View class
    public void removeFromIndexDatabase()
    {
    	// Create the EM
    	Index removeIndex;
    	EntityManager em = Index.indexFactory.createEntityManager();
    	EntityTransaction et = em.getTransaction();
    	
    	// Steps to remove selected data
    	et.begin();
    	removeIndex = em.merge(this);
    	em.remove(removeIndex);
    	et.commit();
    	em.close();	
    }
    
    // Method to check current database items and validate the existence of the current items
    public static void rebuildIndex() throws HeadlessException, ParseException, IOException
    {
    	// Create EMF and EM
    	EntityManagerFactory emf = Persistence.createEntityManagerFactory( "MyDB_CornerTeam03" );
    	EntityManager em = emf.createEntityManager();
    	
    	// Variables to keep track of modified and non-modified file counts
    	int countNotModified = 0;
    	int countModified = 0;
    	int countOfFiles = 0;
    	float fltNotModifiedPercent;
    	float fltModifiedPercent;

    	// Create query that will return all records in the Index table
    	Query getAllIndex = em.createQuery("SELECT x FROM Index x");
    	@SuppressWarnings("unchecked")
    	List<Index> listIndex = getAllIndex.getResultList();

    	// For each record collected by the query, add that record's file path value
    	// to the Admin List
    	for (Index index : listIndex )
    	{
    		// Get a simple count of all files in the current index
    		countOfFiles++;
    		if (index.fileExists() == true && index.fileModified() == false)
    		{
    			countNotModified++;
    		}
    		else if (index.fileModified() == true)
    		{
    			System.out.println("placeholder for inverted index rebuild code");
    			//the code to rebuild the physical text file with the inverted index of each file in the database
    			//will go here.
    			countModified++;
    		}
    	}
    	
    	// Variables will hold the percent of files that are up-to-date and those that have
    	// been modified by the user or system
    	//fltNotModifiedPercent = (countNotModified/countOfFiles) * 100;
    	//fltModifiedPercent = (countModified/countOfFiles) * 100;
    	
    	// This dialog box will inform the user of how many files have been modified and how many
    	// are up-to-date
    	//JOptionPane.showMessageDialog(null, ""
    			//+ "Up-to-Date files: " + countNotModified + " (" + fltNotModifiedPercent + "% of files)"
    			//+ "\n" 
    			//+ "Files modified: " + countModified + " (" + fltModifiedPercent + "% of files)");
    	
    	String[] fileFeed = new String[countOfFiles];
    	
    	int n = 0;
    	for(Index index : listIndex)
		{
			fileFeed[n] = index.getFilePath().replace("\\","\\\\");
			n++;
		}
    	
    	IndexBuild invertedIndex = new IndexBuild();
    	invertedIndex.buildIndex(fileFeed);
    }
 }
