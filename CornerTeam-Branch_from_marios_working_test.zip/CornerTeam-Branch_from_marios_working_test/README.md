# CornerTeam
Java II Project 3
Team Members: Errol Keith
              Tyler Swessel
              Mario Gomez

This file describes the workflow process for the group.
For project 3 Errol will be working as the lead and this will rotate on subsequent projects.

Errol will be responsible for creating a class diagram, creating the Github repo, and managing the aforementioned repo to reflect the agreed upon final project submission. He will also write the methods required.

Tyler will be responsible for writing the stub methods for the non-functional GUI to reflect the class diagram.
 
Mario will write the test case for this assignment and verify the requirements set by the instructor have all been met, and he will also review the code, add items to the issue tracker and begin the creation of the wiki.

Once the architecture is set up and the design is in place, each member will design two panels. One for the admin section, and one for the search engine. This will be done utilizing the stub methods Tyler has created. Upon completion of each panel, we will meet to decide which panels will work best for the assignment and push them to the master for project submission.
  
The team will communicate through a discord server to best facilitate the teams communication needs.
  
Each team member will work either in their local branch or a separate branch from the master in the repo, and the team will communicate which implementations need to be merged with the master branch for final project submission. Subsequent projects will attempt to utilize the same methods building on a single master branch for each project.

  
